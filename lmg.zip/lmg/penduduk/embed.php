<!DOCTYPE html>
<html>
<?php 
	$file = $_GET['id'];
 ?>
<body>
<embed src=<?php echo "../files/".$file; ?> width="100%" height="600"></embed>

</body>
</html>
