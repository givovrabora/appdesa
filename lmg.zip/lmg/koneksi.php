<?php 
	$_mysqli = new mysqli("localhost","root","","lmg"); 
	return $_mysqli;
 ?>